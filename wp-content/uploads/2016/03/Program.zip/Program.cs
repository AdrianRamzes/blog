﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDWD_msdcNN_MinHash
{
    class Program
    {
        public static object sync = new object();

        private delegate uint HashFunction(int index);
        private static HashFunction[] _hashFunctions;
        private static readonly int _numHashFunctions = 100;
        private static readonly int _numRowPerBand = 5;

        private static void InitializeHashFunctions(int universeSize)
        {
            _hashFunctions = new HashFunction[_numHashFunctions];

            Random rand = new Random(13);
            for (int i = 0; i < _numHashFunctions; i++)
            {
                int a = rand.Next(universeSize);
                int b = rand.Next(universeSize);
                int p = 28000019;// First Prime Number Greater Than Biggest Identifier
                _hashFunctions[i] = input => GetHash(a, b, p, input);
            }
        }

        private static uint GetHash(int a, int b, int p, int input)
        {
            return (uint)((a * input + b) % p);
        }

        private static uint[] GetMinHash(IEnumerable<int> set)
        {
            var minHashes = new uint[_numHashFunctions];
            for (int i = 0; i < _numHashFunctions; i++)
            {
                minHashes[i] = int.MaxValue;
            }

            foreach (var item in set)//songs: 5 10 15   // 5 -> 55, 10 -> 2, 15 -> 99
            {
                for (int i = 0; i < _numHashFunctions; i++)
                {
                    var hash = _hashFunctions[i](item);
                    minHashes[i] = Math.Min(hash, minHashes[i]);
                }
            }
            return minHashes;
        }

        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            InitializeHashFunctions(28000019);

            #region Loading Data
            Dictionary<int, HashSet<int>> users = new Dictionary<int, HashSet<int>>();
            using (StreamReader sr = File.OpenText("facts.csv"))
            {
                string s = String.Empty;

                var headers = sr.ReadLine().Split(',');
                while ((s = sr.ReadLine()) != null)
                {
                    var values = s.Split(',');
                    int songId = int.Parse(values[0]);
                    int userId = int.Parse(values[1]);

                    if (users.ContainsKey(userId))
                    {
                        if (!users[userId].Contains(songId))
                            users[userId].Add(songId);
                    }
                    else
                    {
                        users[userId] = new HashSet<int>() { songId };
                    }
                }
            }
            stopwatch.Stop();
            Console.WriteLine("Loaded in: {0}s", ((float)stopwatch.ElapsedMilliseconds / 1000));
            #endregion

            stopwatch.Restart();

            //Dictionary<int, HashSet<uint>> usersMinHash = new Dictionary<int, HashSet<uint>>();
            Dictionary<int, uint[]> signatureMatrix = new Dictionary<int, uint[]>();
            Parallel.ForEach(users, user =>
            {
                var hash = GetMinHash(user.Value);
                //usersMinHash[user.Key] = new HashSet<uint>(hash);
                lock (sync)
                {
                    signatureMatrix[user.Key] = hash;
                }
            });

            stopwatch.Stop();
            Console.WriteLine("MinHash in: {0}s", ((float)stopwatch.ElapsedMilliseconds / 1000));

            // W tym miejscu programu signatureMatrix to słownik id użytkownika/tablica Hashów

            List<Dictionary<uint, List<int>>> buckets = new List<Dictionary<uint, List<int>>>();

            stopwatch.Restart();
            Parallel.For(0, (_numHashFunctions / _numRowPerBand), (i) =>
            {
                Dictionary<uint, List<int>> bucket = new Dictionary<uint, List<int>>();
                foreach (var userId in signatureMatrix.Keys)
                {
                    uint hash = 0;
                    for (int j = 0; j < _numRowPerBand; j++)
                    {
                        hash = unchecked(hash * 1174247 + signatureMatrix[userId][_numRowPerBand * i + j]);
                    }

                    if (!bucket.ContainsKey(hash))
                    {
                        bucket[hash] = new List<int>();
                    }
                    bucket[hash].Add(userId);
                }
                lock (sync)
                {
                    buckets.Add(bucket);
                }
            });

            stopwatch.Stop();
            Console.WriteLine("Genereated buckets list in: {0}s", ((float)stopwatch.ElapsedMilliseconds / 1000));


            uint userCount = 0;
            stopwatch.Restart();

            //List<Dictionary<int, HashSet<int>>> NNs = new List<Dictionary<int, HashSet<int>>>();
            Dictionary<int, HashSet<int>> NN = new Dictionary<int, HashSet<int>>();

            foreach (var userId in users.Keys)
            {//initialize
                NN[userId] = new HashSet<int>();
            }

            foreach (var bucket in buckets)
            {
                foreach (var hash in bucket/*.Where(h => h.Value.Count > 1).ToArray()*/)
                {
                    if (hash.Value.Count > 1)
                    {
                        foreach (var userId in hash.Value)
                        {
                            NN[userId].UnionWith(hash.Value);
                        }
                    }
                }
            }


            stopwatch.Stop();
            Console.WriteLine("Concated Nearest in: {0}s", ((float)stopwatch.ElapsedMilliseconds / 1000));



            stopwatch.Restart();
            //SIMILARITY CALCULATING
            Dictionary<int, Dictionary<int, double>> similarity = new Dictionary<int, Dictionary<int, double>>();

            Parallel.ForEach(NN.Where(n => n.Value.Any()).ToArray(), nn =>
            {
                lock (sync)
                {
                    similarity[nn.Key] = new Dictionary<int, double>();
                }

                foreach (var userId in nn.Value)
                {
                    int intersectCount = 0;
                    int unionCount = users[userId].Count + users[nn.Key].Count;
                    if (users[userId].Count < users[nn.Key].Count)
                    {
                        foreach (var currentSong in users[userId])
                        {
                            if (users[nn.Key].Contains(currentSong))
                                intersectCount++;
                        }
                    }
                    else
                    {
                        foreach (var currentSong in users[nn.Key])
                        {
                            if (users[userId].Contains(currentSong))
                                intersectCount++;
                        }
                    }
                    //////----------8<-----------------
                    if (intersectCount > 0)
                    {
                        lock (sync)
                        {
                            similarity[nn.Key][userId] = ((double)intersectCount / (unionCount - intersectCount));
                        }
                    }
                }
            });

            stopwatch.Stop();
            Console.WriteLine("Calculated similarity in: {0}s", ((float)stopwatch.ElapsedMilliseconds / 1000));

            //string resultString = string.Empty;

            var sum = similarity.Sum(s => s.Value.Count);
            var count = similarity.Count(s => s.Value.Count > 1);
            int counter = 0;
            foreach (var sim in similarity.Where(s => s.Value.Count > 1))
            {
                string resultString = string.Format("User\t{0}:{1}", sim.Key, Environment.NewLine);

                foreach (var u in sim.Value.OrderByDescending(k => k.Value).Take(100))
                {
                    if (u.Value == 1)
                        continue;
                    resultString += string.Format("\t{0}\t{1:0.000}{2}", u.Key, u.Value, Environment.NewLine);
                }
                counter++;
                //File.AppendAllText("LSH_result.txt", resultString);
            }
            

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
